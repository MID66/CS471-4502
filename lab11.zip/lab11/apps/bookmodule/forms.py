from django import forms
from .models import (
    Book, Address, Student,
    Address2, Student2, Photo
)

# ==== Lab10: BookForm ====
class BookForm(forms.ModelForm):
    class Meta:
        model  = Book
        fields = ['title','author','price','edition']
        widgets = {
            'title':   forms.TextInput(),
            'author':  forms.TextInput(),
            'price':   forms.NumberInput(attrs={'step':'0.01'}),
            'edition': forms.NumberInput(attrs={'min':1}),
        }
        labels = {
            'title':   'Book Title',
            'author':  'Author Name',
            'price':   'Price',
            'edition': 'Edition Number',
        }

# ==== Lab11 Task 1 Forms ====
class AddressForm(forms.ModelForm):
    class Meta:
        model  = Address
        fields = ['street','city']

class StudentForm(forms.ModelForm):
    class Meta:
        model  = Student
        fields = ['name','age','address']

# ==== Lab11 Task 2 Form ====
class Student2Form(forms.ModelForm):
    addresses = forms.ModelMultipleChoiceField(
        queryset=Address2.objects.all(),
        widget=forms.CheckboxSelectMultiple
    )
    class Meta:
        model  = Student2
        fields = ['name','age','addresses']

# ==== Lab11 Task 3 Form ====
class PhotoForm(forms.ModelForm):
    class Meta:
        model  = Photo
        fields = ['title','image']
