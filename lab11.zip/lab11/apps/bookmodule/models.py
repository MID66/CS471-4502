# lab10/apps/bookmodule/models.py

from django.db import models

# ==== Lab10: Book model ====
class Book(models.Model):
    title   = models.CharField(max_length=50)
    author  = models.CharField(max_length=50)
    price   = models.FloatField(default=0.0)
    edition = models.SmallIntegerField(default=1)

    def __str__(self):
        return self.title


# ==== Lab11 Task 1: One-to-One Student–Address ====
class Address(models.Model):
    street = models.CharField(max_length=255, blank=True, default='')
    city   = models.CharField(max_length=100, blank=True, default='')

    def __str__(self):
        return f"{self.street}, {self.city}"


class Student(models.Model):
    name    = models.CharField(max_length=255)
    age     = models.IntegerField()
    address = models.OneToOneField(Address, on_delete=models.CASCADE)

    def __str__(self):
        return self.name


# ==== Lab11 Task 2: Many-to-Many Student2–Address2 ====
class Address2(models.Model):
    street = models.CharField(max_length=255, blank=True, default='')
    city   = models.CharField(max_length=100, blank=True, default='')

    def __str__(self):
        return f"{self.street}, {self.city}"


class Student2(models.Model):
    name      = models.CharField(max_length=255)
    age       = models.IntegerField()
    addresses = models.ManyToManyField(Address2)

    def __str__(self):
        return self.name


# ==== Lab11 Task 3: Photo upload ====
class Photo(models.Model):
    title = models.CharField(max_length=100)
    image = models.ImageField(upload_to='photos/')

    def __str__(self):
        return self.title
