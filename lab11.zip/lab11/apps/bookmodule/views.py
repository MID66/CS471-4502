from django.shortcuts import render, redirect, get_object_or_404
from .models import Book, Address, Student, Address2, Student2, Photo
from django.db.models import Q, Count, Min, Max, Sum, Avg
from .forms import BookForm, AddressForm, StudentForm, Student2Form, PhotoForm

# Create your views here.
def index(request):
 return render(request, "bookmodule/index.html")

def list_books(request):
 return render(request, 'bookmodule/list_books.html')

def viewbook(request, bookId):
 return render(request, 'bookmodule/one_book.html')

def aboutus(request):
 return render(request, 'bookmodule/aboutus.html')

def links(request):
 return render(request, "bookmodule/links.html")

def textformats(request):
 return render(request, "bookmodule/text/formatting.html")

def listing(request):
 return render(request, "bookmodule/listing.html")

def table(request):
 return render(request, "bookmodule/table.html")

def simple_query(request):
 mybooks = Book.objects.filter(title__icontains='and')
 return render(request, 'bookmodule/queryQ.html', {'books': mybooks})

def list_q(request):
 mybooks = Book.objects.filter(Q(price__lte=50))
 return render(request, 'bookmodule/queryQ.html', {'books': mybooks})

def list_q2(request):
 mybooks = Book.objects.filter(
  Q(edition__gt=2) &
  (Q(title__contains="qu") | Q(author__contains="qu"))
 )
 return render(request, 'bookmodule/queryQ.html', {'books': mybooks})

def list_q3(request):
 mybooks = Book.objects.filter(
  Q(edition__lte=2) &
  ~(Q(title__contains="qu") | Q(author__contains="qu"))
 )
 return render(request, 'bookmodule/queryQ.html', {'books': mybooks})

def list_q4(request):
 mybooks = Book.objects.order_by('title')
 return render(request, 'bookmodule/queryQ.html', {'books': mybooks})

def list_q5(request):
 total = Book.objects.count()
 stats = Book.objects.aggregate(
  total=Count('title'),
  sum=Sum('price', default=0),
  max=Max('price', default=0),
  min=Min('price', default=0)
 )
 return render(request, 'bookmodule/queryQ5.html', {'books': stats})

def list_q6(request):
 mybooks = Book.objects.annotate(num_authors=Count('author'))
 return render(request, 'bookmodule/queryQ5.html', {'books': mybooks})

def listbooks9(request):
 mybooks = Book.objects.all()
 return render(request, 'bookmodule/listbooks9.html', {'books': mybooks})

def lab9_addbook(request):
 if request.method == 'POST':
  title       = request.POST.get('title')
  price       = request.POST.get('price')
  edition     = request.POST.get('edition')
  author_name = request.POST.get('author_name')
  obj = Book(
   title=title,
   price=float(price),
   edition=edition,
   author=author_name
  )
  obj.save()
  return redirect('/books/lab9_part1/listbooks')
 return render(request, "bookmodule/addbook.html")

def lab9_updateBook(request, bookId):
 obj = Book.objects.get(id=bookId)
 if request.method == 'POST':
  title       = request.POST.get('title')
  price       = request.POST.get('price')
  edition     = request.POST.get('edition')
  author_name = request.POST.get('author_name')
  obj.title   = title
  obj.price   = float(price)
  obj.edition = edition
  obj.author  = author_name
  obj.save()
  return redirect('/books/lab9_part1/listbooks')
 return render(request, "bookmodule/editbook.html", {'book': obj})

def lab9_deleteBook(request, bookId):
 obj = Book.objects.get(id=bookId)
 if request.method == 'POST':
  obj.delete()
  return redirect('/books/lab9_part1/listbooks')
 return render(request, "bookmodule/deletebook.html", {'book': obj})

def lab9_2_addbook(request):
 if request.method == 'POST':
  form = BookForm(request.POST)
  if form.is_valid():
   form.save()
   return redirect('/books/lab9_part1/listbooks')
 else:
  form = BookForm()
 return render(request, "bookmodule/addbook_task2.html", {'form': form})

def lab9_2_editbook(request, bookId):
 obj = Book.objects.get(id=bookId)
 if request.method == 'POST':
  form = BookForm(request.POST, instance=obj)
  if form.is_valid():
   form.save()
   return redirect('/books/lab9_part1/listbooks')
 else:
  form = BookForm(instance=obj)
 return render(request, "bookmodule/editbook_task2.html", {'form': form})


# ==== Lab11 Task 1: CRUD for Student–Address (One-to-One) ====
def student_list(request):
 students = Student.objects.select_related('address').all()
 return render(request, 'bookmodule/student_list.html', {'students': students})

def student_create(request):
 if request.method == 'POST':
  form = StudentForm(request.POST)
  if form.is_valid():
   form.save()
   return redirect('student_list')
 else:
  form = StudentForm()
 return render(request, 'bookmodule/student_form.html', {'form': form})

def student_update(request, pk):
 student = get_object_or_404(Student, pk=pk)
 if request.method == 'POST':
  form = StudentForm(request.POST, instance=student)
  if form.is_valid():
   form.save()
   return redirect('student_list')
 else:
  form = StudentForm(instance=student)
 return render(request, 'bookmodule/student_form.html', {'form': form})

def student_delete(request, pk):
 student = get_object_or_404(Student, pk=pk)
 if request.method == 'POST':
  student.delete()
  return redirect('student_list')
 return render(request, 'bookmodule/student_confirm_delete.html', {'student': student})


# ==== Lab11 Task 2: CRUD for Student2–Address2 (Many-to-Many) ====
def student2_list(request):
 students2 = Student2.objects.prefetch_related('addresses').all()
 return render(request, 'bookmodule/student2_list.html', {'students2': students2})

def student2_create(request):
 if request.method == 'POST':
  form = Student2Form(request.POST)
  if form.is_valid():
   form.save()
   return redirect('student2_list')
 else:
  form = Student2Form()
 return render(request, 'bookmodule/student2_form.html', {'form': form})

def student2_update(request, pk):
 student2 = get_object_or_404(Student2, pk=pk)
 if request.method == 'POST':
  form = Student2Form(request.POST, instance=student2)
  if form.is_valid():
   form.save()
   return redirect('student2_list')
 else:
  form = Student2Form(instance=student2)
 return render(request, 'bookmodule/student2_form.html', {'form': form})

def student2_delete(request, pk):
 student2 = get_object_or_404(Student2, pk=pk)
 if request.method == 'POST':
  student2.delete()
  return redirect('student2_list')
 return render(request, 'bookmodule/student2_confirm_delete.html', {'student2': student2})


# ==== Lab11 Task 3: CRUD for Photo upload ====
def photo_list(request):
 photos = Photo.objects.all()
 return render(request, 'bookmodule/photo_list.html', {'photos': photos})

def photo_create(request):
 if request.method == 'POST':
  form = PhotoForm(request.POST, request.FILES)
  if form.is_valid():
   form.save()
   return redirect('photo_list')
 else:
  form = PhotoForm()
 return render(request, 'bookmodule/photo_form.html', {'form': form})
