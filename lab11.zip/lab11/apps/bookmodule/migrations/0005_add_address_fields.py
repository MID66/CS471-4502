from django.db import migrations, models

class Migration(migrations.Migration):
    dependencies = [
        ('bookmodule', '0002_address_student'),
    ]

    operations = [
        migrations.AddField(
            model_name='address',
            name='street',
            field=models.CharField(max_length=255, blank=True, default=''),
        ),
        migrations.AlterField(
            model_name='address',
            name='city',
            field=models.CharField(max_length=100, blank=True, default=''),
        ),
    ]
